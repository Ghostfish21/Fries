﻿using System;
using System.Collections.Generic;
using Fries.Pool;
using UnityEditor;
using UnityEngine;

namespace Fries.BlockGrid {
    public struct BoundsInfo {
        public int type;
        public Bounds bounds;
        public BoundsInfo(Bounds bounds, int type) {
            this.bounds = bounds;
            this.type = type;
        }
    }
    
    [Serializable]
    public class IrregularPartMap {
        public readonly float cellSize;
        private readonly EverythingPool everythingPool;
        private readonly Transform space;

        public IrregularPartMap(float cellSize, EverythingPool everythingPool, Transform space) {
            if (cellSize <= 0f) throw new ArgumentOutOfRangeException(nameof(cellSize), "cellSize must be > 0");
            this.cellSize = cellSize;
            this.everythingPool = everythingPool;
            this.space = space;
        }

        // cell -> ids in that cell
        private readonly Dictionary<Vector3Int, List<int>> spatialHash = new();
        // id -> bounds
        private readonly Dictionary<int, BoundsInfo> boundsMap = new();
        // id -> occupied cells
        private readonly Dictionary<int, List<Vector3Int>> id2Cells = new();
        // id -> custom data
        private readonly Dictionary<int, Dictionary<int, object>> customData = new();

        public readonly List<(int, object)> CustomDataRegister = new();
        
        private int _nextId = 1;

        public bool drawGizmos;

        public bool TryGetData(int id, out Dictionary<int, object> dataDict) =>
            customData.TryGetValue(id, out dataDict);
        
        public int AddBounds(Bounds bounds, int type = 0) {
            int id = _nextId++;
            boundsMap[id] = new BoundsInfo(bounds, type);

            var cells = everythingPool.ActivateObject<List<Vector3Int>>();
            getCellsCovered(bounds, cells);
            id2Cells[id] = cells;

            foreach (var cell in cells) {
                if (!spatialHash.TryGetValue(cell, out var list)) {
                    list = everythingPool.ActivateObject<List<int>>();
                    spatialHash[cell] = list;
                }
                list.Add(id);
            }

            var dataDict = everythingPool.ActivateObject<Dictionary<int, object>>();
            customData[id] = dataDict;
            foreach (var valueTuple in CustomDataRegister) 
                dataDict[valueTuple.Item1] = valueTuple.Item2;
            
            return id;
        }
        
        private void releaseCustomData(int id) {
            if (!customData.Remove(id, out var dataDict)) return;
            everythingPool.DeactivateObject(dataDict);
        }

        public void RemoveBounds(int id) {
            if (!boundsMap.Remove(id)) return;

            if (!id2Cells.TryGetValue(id, out var cells)) 
                throw new KeyNotFoundException("Cannot find cells for id " + id +
                                               " when removing bounds. This is a bug and should not happen.");
            
            foreach (var cell in cells) {
                if (!spatialHash.TryGetValue(cell, out var list)) continue;
                list.Remove(id);
                if (list.Count == 0) {
                    spatialHash.Remove(cell, out var ints);
                    everythingPool.DeactivateObject(ints);
                }
            }
            id2Cells.Remove(id);
            everythingPool.DeactivateObject(cells);
            releaseCustomData(id);
        }

        public bool UpdateBounds(int id, Bounds bounds) {
            if (!boundsMap.TryGetValue(id, out var bi)) return false;

            // 先从旧 cells 移除
            if (id2Cells.TryGetValue(id, out var oldCells)) {
                foreach (var cell in oldCells) {
                    if (!spatialHash.TryGetValue(cell, out var list)) continue;
                    list.Remove(id);
                    if (list.Count == 0) {
                        spatialHash.Remove(cell, out var ints);
                        everythingPool.DeactivateObject(ints);
                    }
                }
            }

            // 再添加到新 cells
            boundsMap[id] = new BoundsInfo(bounds, bi.type);

            var newCells = everythingPool.ActivateObject<List<Vector3Int>>();
            getCellsCovered(bounds, newCells);
            if (id2Cells.TryGetValue(id, out var oldList))
                everythingPool.DeactivateObject(oldList);
            id2Cells[id] = newCells;

            foreach (var cell in newCells) {
                if (!spatialHash.TryGetValue(cell, out var list)) {
                    list = everythingPool.ActivateObject<List<int>>();
                    spatialHash[cell] = list;
                }
                list.Add(id);
            }

            return true;
        }

        public void Clear() {
            foreach (var kv in id2Cells) 
                everythingPool.DeactivateObject(kv.Value);
            id2Cells.Clear();
            foreach (var kv in spatialHash) 
                everythingPool.DeactivateObject(kv.Value);
            spatialHash.Clear();
            boundsMap.Clear();
            
            foreach (var kv in customData) {
                kv.Value.Clear();
                everythingPool.DeactivateObject(kv.Value);
            }
            customData.Clear();
            
            _nextId = 1;
        }
        
        public bool CollisionTest(Bounds toBeTested, List<Bounds> collidesWith = null) {
            collidesWith?.Clear();

            // 候选去重：同一个 id 可能出现在多个 cell
            var visited = everythingPool.ActivateObject<HashSet<int>>();
            var cells = everythingPool.ActivateObject<List<Vector3Int>>();
            try {
                getCellsCovered(toBeTested, cells);

                foreach (var t in cells) {
                    if (!spatialHash.TryGetValue(t, out var ids)) continue;

                    foreach (var id in ids) {
                        if (!visited.Add(id)) continue;

                        if (!boundsMap.TryGetValue(id, out var b)) continue;

                        if (!b.bounds.Intersects(toBeTested)) continue;
                        if (collidesWith != null) collidesWith.Add(b.bounds);
                        else return true;
                    }
                }
            }
            finally {
                everythingPool.DeactivateObject(cells);
                everythingPool.DeactivateObject(visited);
            }

            return collidesWith is { Count: > 0 };
        }

        public List<(int, BoundsInfo, List<Vector3Int>)> FindParts(IrregularPartQueryFilter filter = default) {
            var result = new List<(int, BoundsInfo, List<Vector3Int>)>();

            bool hasType = filter.type.HasValue;
            int type = filter.type.GetValueOrDefault();

            bool hasPos1 = filter.pos1.HasValue;
            bool hasPos2 = filter.pos2.HasValue;

            bool TypeMatch(BoundsInfo bi) => !hasType || bi.type == type;

            // 没有空间条件：直接扫全表（仍然支持 type 过滤）
            if (!hasPos1 && !hasPos2) {
                foreach (var kv in boundsMap) {
                    if (!TypeMatch(kv.Value)) continue;
                    result.Add((kv.Key, kv.Value, id2Cells[kv.Key]));
                }

                return result;
            }

            // 单点查询：pos1 或 pos2
            void PointQuery(Vector3 p) {
                var cell = worldToCell(p);
                if (!spatialHash.TryGetValue(cell, out var ids)) return;

                foreach (var id in ids) {
                    if (!boundsMap.TryGetValue(id, out var bi)) continue;
                    if (!TypeMatch(bi)) continue;
                    if (!bi.bounds.Contains(p)) continue;
                    result.Add((id, bi, id2Cells[id]));
                }
            }

            if (hasPos1 && !hasPos2) {
                PointQuery(filter.pos1.Value);
                return result;
            }

            if (!hasPos1 && hasPos2) {
                PointQuery(filter.pos2.Value);
                return result;
            }

            // pos1 + pos2：AABB 查询（以两点作为盒子的对角点）
            var p1 = filter.pos1.Value;
            var p2 = filter.pos2.Value;

            // 两点几乎重合：退化为单点
            if ((p1 - p2).sqrMagnitude <= 1e-12f) {
                PointQuery(p1);
                return result;
            }

            var min = Vector3.Min(p1, p2);
            var max = Vector3.Max(p1, p2);
            var queryBounds = new Bounds((min + max) * 0.5f, max - min);

            // 候选去重：同一个 id 可能出现在多个 cell
            var visited = everythingPool.ActivateObject<HashSet<int>>();
            var cells = everythingPool.ActivateObject<List<Vector3Int>>();
            try {
                getCellsCovered(queryBounds, cells);

                foreach (var cell in cells) {
                    if (!spatialHash.TryGetValue(cell, out var ids)) continue;

                    foreach (var id in ids) {
                        if (!visited.Add(id)) continue;

                        if (!boundsMap.TryGetValue(id, out var bi)) continue;
                        if (!TypeMatch(bi)) continue;
                        if (!bi.bounds.Intersects(queryBounds)) continue;

                        result.Add((id, bi, id2Cells[id]));
                    }
                }
            }
            finally {
                everythingPool.DeactivateObject(cells);
                everythingPool.DeactivateObject(visited);
            }

            return result;
        }

        // ---------- helpers ----------

        private Vector3 toGridSpace(Vector3 worldPos) {
            return space ? space.InverseTransformPoint(worldPos) : worldPos;
        }

        private Vector3Int gridPosToCell(Vector3 gridPos) {
            float inv = 1f / cellSize;
            // 中心对齐：+0.5 cell
            return new Vector3Int(
                Mathf.FloorToInt(gridPos.x * inv + 0.5f),
                Mathf.FloorToInt(gridPos.y * inv + 0.5f),
                Mathf.FloorToInt(gridPos.z * inv + 0.5f)
            );
        }

        private Vector3Int worldToCell(Vector3 worldPos) => gridPosToCell(toGridSpace(worldPos));

        private Bounds worldBoundsToGridAabb(Bounds worldB) {
            if (!space) return worldB;

            var c = worldB.center;
            var e = worldB.extents;

            // 8 corners -> grid space，然后取 AABB
            Vector3 min = new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity);
            Vector3 max = new Vector3(float.NegativeInfinity, float.NegativeInfinity, float.NegativeInfinity);

            void push(Vector3 w) {
                var p = space.InverseTransformPoint(w);
                min = Vector3.Min(min, p);
                max = Vector3.Max(max, p);
            }

            push(c + new Vector3(-e.x, -e.y, -e.z));
            push(c + new Vector3(-e.x, -e.y, +e.z));
            push(c + new Vector3(-e.x, +e.y, -e.z));
            push(c + new Vector3(-e.x, +e.y, +e.z));
            push(c + new Vector3(+e.x, -e.y, -e.z));
            push(c + new Vector3(+e.x, -e.y, +e.z));
            push(c + new Vector3(+e.x, +e.y, -e.z));
            push(c + new Vector3(+e.x, +e.y, +e.z));

            return new Bounds((min + max) * 0.5f, max - min);
        }

        private void getCellsCovered(Bounds worldB, List<Vector3Int> cells) {
            var b = worldBoundsToGridAabb(worldB);

            var min = gridPosToCell(b.min);
            var max = gridPosToCell(b.max - Vector3.one * 1e-6f);

            if (max.x < min.x) max.x = min.x;
            if (max.y < min.y) max.y = min.y;
            if (max.z < min.z) max.z = min.z;

            for (int x = min.x; x <= max.x; x++)
            for (int y = min.y; y <= max.y; y++)
            for (int z = min.z; z <= max.z; z++)
                cells.Add(new Vector3Int(x, y, z));
        }
        
        public void DrawAllBoundsGizmos(float lineWidth = 2f) {
#if UNITY_EDITOR
            if (drawGizmos) {
                Handles.color = Color.black;
                foreach (var b in boundsMap.Values)
                    DrawBoundsWireThick(b.bounds, lineWidth);
            }
#endif
        }

#if UNITY_EDITOR
        private static void DrawBoundsWireThick(Bounds b, float lineWidth) {
            var c = b.center;
            var e = b.extents;

            // 8 corners
            var p000 = c + new Vector3(-e.x, -e.y, -e.z);
            var p001 = c + new Vector3(-e.x, -e.y, +e.z);
            var p010 = c + new Vector3(-e.x, +e.y, -e.z);
            var p011 = c + new Vector3(-e.x, +e.y, +e.z);
            var p100 = c + new Vector3(+e.x, -e.y, -e.z);
            var p101 = c + new Vector3(+e.x, -e.y, +e.z);
            var p110 = c + new Vector3(+e.x, +e.y, -e.z);
            var p111 = c + new Vector3(+e.x, +e.y, +e.z);

            // 12 edges
            Handles.DrawAAPolyLine(lineWidth, p000, p001);
            Handles.DrawAAPolyLine(lineWidth, p000, p010);
            Handles.DrawAAPolyLine(lineWidth, p000, p100);

            Handles.DrawAAPolyLine(lineWidth, p111, p110);
            Handles.DrawAAPolyLine(lineWidth, p111, p101);
            Handles.DrawAAPolyLine(lineWidth, p111, p011);

            Handles.DrawAAPolyLine(lineWidth, p001, p011);
            Handles.DrawAAPolyLine(lineWidth, p001, p101);

            Handles.DrawAAPolyLine(lineWidth, p010, p011);
            Handles.DrawAAPolyLine(lineWidth, p010, p110);

            Handles.DrawAAPolyLine(lineWidth, p100, p101);
            Handles.DrawAAPolyLine(lineWidth, p100, p110);
        }
#endif
    }
}
